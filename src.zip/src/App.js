import logo from './logo.svg';
import './App.css';
import React from 'react';
import Form from './ck1/form';

function App() {
  return (
    <Form></Form>
  );
}

export default App;